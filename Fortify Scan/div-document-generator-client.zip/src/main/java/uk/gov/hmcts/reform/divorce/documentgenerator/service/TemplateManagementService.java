package uk.gov.hmcts.reform.divorce.documentgenerator.service;

public interface TemplateManagementService {

    byte[] getTemplateByName(String templateName);

}
